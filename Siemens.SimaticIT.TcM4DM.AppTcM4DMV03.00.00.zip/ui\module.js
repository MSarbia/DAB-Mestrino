﻿(function () {
    'use strict';
    angular.module('Siemens.SimaticIT.TcM4DM.AppTcM4DM', []);
})();
